# Food-Delivery-System

In this project, we designed a food delivery system based on software engineering knowledge.

- Software Engineering Final Project - Under supervision of Dr. Alirezaei

- Impelemented by :
  - [Samin Mahdipour](https://github.com/Precioux) <br />
  - [Yeganeh Arabi Moghadam](https://github.com/ygarabimoghadam) <br />
  - [Negar Soltan Mohammadi](https://github.com/negrsm) <br />
- Amirkabir University of Technology - Fall 2022
